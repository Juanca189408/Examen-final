using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using Proyecto2_Upi.Models;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly ApplicationDbContext _context;

    public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
    {
        _logger = logger;
        _context = context;
    }

    [HttpGet]
    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Index(string actionType, string numeroPasaporte, string contrasena, string confirmContrasena, string nombre, string apellido, DateTime? fechaNacimiento, string nacionalidad)
    {
        if (actionType == "Register")
        {
            if (contrasena != confirmContrasena)
            {
                ViewData["ErrorMessage"] = "Las contrase�as no coinciden";
                return View();
            }

            var existingViajero = await _context.Viajeros
                .FirstOrDefaultAsync(v => v.NumeroPasaporte == numeroPasaporte);

            if (existingViajero != null)
            {
                ViewData["ErrorMessage"] = "El n�mero de pasaporte ya est� registrado";
                return View();
            }

            var newViajero = new Viajero
            {
                Nombre = nombre,
                Apellido = apellido,
                FechaNacimiento = fechaNacimiento.Value,
                Nacionalidad = nacionalidad,
                NumeroPasaporte = numeroPasaporte,
                Contrasena = HashPassword(contrasena)
            };

            _context.Viajeros.Add(newViajero);
            await _context.SaveChangesAsync();

            ViewData["SuccessMessage"] = "Usuario registrado exitosamente.";
            return View();
        }
        else if (actionType == "Login")
        {
            var viajero = await _context.Viajeros
                .FirstOrDefaultAsync(v => v.NumeroPasaporte == numeroPasaporte);

            if (viajero != null && VerifyPassword(viajero, contrasena))
            {
                return RedirectToAction("Privacy");
            }
            else
            {
                ViewData["ErrorMessage"] = "N�mero de pasaporte o contrase�a incorrectos";
            }
        }

        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    public IActionResult Destinos()
    {
        return View();
    }

    public IActionResult Salir()
    {
        return RedirectToAction("Index");
    }


    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }

    private string HashPassword(string password)
    {
        using (var hmac = new HMACSHA256())
        {
            return Convert.ToBase64String(hmac.ComputeHash(Encoding.UTF8.GetBytes(password)));
        }
    }

    private bool VerifyPassword(Viajero viajero, string password)
    {
        var hashedPassword = HashPassword(password);
        return viajero.Contrasena == hashedPassword;
    }

    public class MateriaDto
    {
        public string Name { get; set; }
        public decimal Cost { get; set; }
    }
}
