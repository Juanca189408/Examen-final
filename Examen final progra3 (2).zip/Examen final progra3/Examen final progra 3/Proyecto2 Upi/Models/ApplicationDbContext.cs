﻿using Microsoft.EntityFrameworkCore;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<Viajero> Viajeros { get; set; }
    public DbSet<Pais> Paises { get; set; }
    public DbSet<Entrada> Entradas { get; set; }
    public DbSet<Salida> Salidas { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Viajero>()
            .HasKey(v => v.ViajeroID);

        modelBuilder.Entity<Pais>()
            .HasKey(p => p.PaisID);

        modelBuilder.Entity<Entrada>()
            .HasKey(e => e.EntradaID);

        modelBuilder.Entity<Salida>()
            .HasKey(s => s.SalidaID);

        modelBuilder.Entity<Entrada>()
            .HasIndex(e => new { e.ViajeroID, e.PaisID, e.FechaEntrada })
            .IsUnique();

        modelBuilder.Entity<Salida>()
            .HasIndex(s => new { s.ViajeroID, s.PaisID, s.FechaSalida })
            .IsUnique();

        modelBuilder.Entity<Entrada>()
            .HasOne(e => e.Viajero)
            .WithMany()
            .HasForeignKey(e => e.ViajeroID);

        modelBuilder.Entity<Entrada>()
            .HasOne(e => e.Pais)
            .WithMany()
            .HasForeignKey(e => e.PaisID);

        modelBuilder.Entity<Salida>()
            .HasOne(s => s.Viajero)
            .WithMany()
            .HasForeignKey(s => s.ViajeroID);

        modelBuilder.Entity<Salida>()
            .HasOne(s => s.Pais)
            .WithMany()
            .HasForeignKey(s => s.PaisID);
    }
}
