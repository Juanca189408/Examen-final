﻿public class Salida
{
    public int SalidaID { get; set; }
    public int ViajeroID { get; set; }
    public int PaisID { get; set; }
    public DateTime FechaSalida { get; set; }
    public string TipoSalida { get; set; }

    public Viajero Viajero { get; set; }
    public Pais Pais { get; set; }
}
