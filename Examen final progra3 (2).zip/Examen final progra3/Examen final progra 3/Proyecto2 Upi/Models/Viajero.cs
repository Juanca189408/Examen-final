﻿public class Viajero
{
    public int ViajeroID { get; set; } 
    public string Contrasena { get; set; }
    public string Nombre { get; set; }
    public string Apellido { get; set; }
    public DateTime FechaNacimiento { get; set; }
    public string Nacionalidad { get; set; }
    public string NumeroPasaporte { get; set; }
}

