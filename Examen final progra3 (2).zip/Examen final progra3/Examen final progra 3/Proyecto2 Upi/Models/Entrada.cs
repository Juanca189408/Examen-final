﻿public class Entrada
{
    public int EntradaID { get; set; }
    public int ViajeroID { get; set; }
    public int PaisID { get; set; }
    public DateTime FechaEntrada { get; set; }
    public string TipoEntrada { get; set; }

    public Viajero Viajero { get; set; }
    public Pais Pais { get; set; }
}
