﻿public class Pais
{
    public int PaisID { get; set; }
    public string Nombre { get; set; }
    public string CodigoISO { get; set; }
}
