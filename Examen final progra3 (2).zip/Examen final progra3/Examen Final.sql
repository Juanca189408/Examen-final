Create database ExamenF

use  ExamenF

CREATE TABLE Viajeros (
    ViajeroID INT PRIMARY KEY IDENTITY(1,1),
	Contrasena NVARCHAR(255) NOT NULL,
    Nombre NVARCHAR(100) NOT NULL,
    Apellido NVARCHAR(100) NOT NULL,
    FechaNacimiento DATE NOT NULL,
    Nacionalidad NVARCHAR(50) NOT NULL,
    NumeroPasaporte NVARCHAR(20) UNIQUE NOT NULL
);

CREATE TABLE Paises (
    PaisID INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL UNIQUE,
    CodigoISO NVARCHAR(3) NOT NULL UNIQUE
);

CREATE TABLE Entradas (
    EntradaID INT PRIMARY KEY IDENTITY(1,1),
    ViajeroID INT NOT NULL,
    PaisID INT NOT NULL,
    FechaEntrada DATE NOT NULL,
    TipoEntrada NVARCHAR(50),
    FOREIGN KEY (ViajeroID) REFERENCES Viajeros(ViajeroID),
    FOREIGN KEY (PaisID) REFERENCES Paises(PaisID),
    CONSTRAINT UQ_Entrada UNIQUE (ViajeroID, PaisID, FechaEntrada)
);


CREATE TABLE Salidas (
    SalidaID INT PRIMARY KEY IDENTITY(1,1),
    ViajeroID INT NOT NULL,
    PaisID INT NOT NULL,
    FechaSalida DATE NOT NULL,
    TipoSalida NVARCHAR(50),
    FOREIGN KEY (ViajeroID) REFERENCES Viajeros(ViajeroID),
    FOREIGN KEY (PaisID) REFERENCES Paises(PaisID),
    CONSTRAINT UQ_Salida UNIQUE (ViajeroID, PaisID, FechaSalida)
);

INSERT INTO Viajeros (Contrasena, Nombre, Apellido, FechaNacimiento, Nacionalidad, NumeroPasaporte)
VALUES 
('0000', 'Juan', 'P�rez', '1990-05-15', 'Espa�ola', 'X1234567'),
('1111', 'Ana', 'Garc�a', '1985-09-30', 'Argentina', 'Y7654321'),
('2222', 'Luis', 'Mart�nez', '2000-02-20', 'Mexicana', 'Z1122334');

select * from Viajeros